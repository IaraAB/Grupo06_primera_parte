package Presentacion;

public class Main {
	
	private static Sistema sistema=Sistema.getInstancia();

	public static void main(String[] args) {
		
		
		sistema.main();
	}

}
