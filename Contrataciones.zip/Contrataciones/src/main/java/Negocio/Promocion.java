package Negocio;

public abstract class Promocion{
	
	public abstract void Descuento(Contrato contratacion);

}