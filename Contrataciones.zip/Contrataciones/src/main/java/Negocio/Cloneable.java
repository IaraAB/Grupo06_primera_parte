package Negocio;

public interface Cloneable {

}
