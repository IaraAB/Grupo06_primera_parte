package Negocio;

public interface Contrato {

}
