package Datos;

public class PersonaFisica extends Abonado{

	public PersonaFisica(String nombre, int dni) {
		super(nombre, dni);
	}

}
