package Datos;

public class PersonaJuridica extends Abonado{

	public PersonaJuridica(String nombre, int dni) {
		super(nombre, dni);
	}
}
